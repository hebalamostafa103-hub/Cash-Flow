<?php
require_once "../config/db.php";
require_once "../helpers/response.php";

try {
   $input = json_decode(
    file_get_contents("php://input"),
    true
);

$user_id = intval(
    $input["user_id"] ?? 0
);

$stmt = $conn->prepare("
    SELECT *
    FROM clients
    WHERE user_id = :user_id
    ORDER BY id DESC
");

$stmt->execute([
    ":user_id" => $user_id
]);

response(
    true,
    "Clients loaded",
    $stmt->fetchAll()
);

} catch (Exception $e) {
    response(false, "Failed to load clients", null, 500);
}