<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once "../config/db.php";

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!$data) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid JSON body"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$type = isset($data["type"]) ? trim($data["type"]) : "";
$partyType = isset($data["party_type"]) ? trim($data["party_type"]) : "";
$partyId = isset($data["party_id"]) && $data["party_id"] !== "" ? intval($data["party_id"]) : null;
$title = isset($data["title"]) ? trim($data["title"]) : "";
$amount = isset($data["amount"]) ? abs(floatval($data["amount"])) : 0;
$note = isset($data["note"]) ? trim($data["note"]) : "";
$user_id = intval($data["user_id"] ?? 0);

if ($type === "" || $partyType === "" || $title === "" || $amount <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Missing required fields"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$allowedTypes = ["sale", "purchase", "receive", "pay"];

if (!in_array($type, $allowedTypes)) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid transaction type"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $conn->beginTransaction();

    /*
        1) تسجيل العملية في جدول transactions
    */
    $stmt = $conn->prepare("
        INSERT INTO transactions
(user_id, type, party_type, party_id, title, amount, note, created_at)
        VALUES
(:user_id, :type, :party_type, :party_id, :title, :amount, :note, NOW())
    ");

    $stmt->bindValue(":user_id", $user_id, PDO::PARAM_INT);
    $stmt->bindValue(":type", $type);
    $stmt->bindValue(":party_type", $partyType);

    if ($partyId === null) {
        $stmt->bindValue(":party_id", null, PDO::PARAM_NULL);
    } else {
        $stmt->bindValue(":party_id", $partyId, PDO::PARAM_INT);
    }

    $stmt->bindValue(":title", $title);
    $stmt->bindValue(":amount", $amount);
    $stmt->bindValue(":note", $note);

    $stmt->execute();

    $transactionId = $conn->lastInsertId();

    /*
        2) إنشاء تنبيه تلقائي للعملية
    */
    $notificationTitle = "";
    $notificationBody = "";
    $notificationType = "info";

    if ($type === "sale") {
        $notificationTitle = "عملية بيع جديدة";
        $notificationBody = "تم تسجيل عملية بيع بقيمة " . $amount . " ج.م - " . $title;
        $notificationType = "money";
    } elseif ($type === "purchase") {
        $notificationTitle = "عملية شراء جديدة";
        $notificationBody = "تم تسجيل عملية شراء بقيمة " . $amount . " ج.م - " . $title;
        $notificationType = "stock";
    } elseif ($type === "receive") {
        $notificationTitle = "استلام أموال";
        $notificationBody = "تم استلام مبلغ " . $amount . " ج.م - " . $title;
        $notificationType = "money";
    } elseif ($type === "pay") {
        $notificationTitle = "دفع أموال";
        $notificationBody = "تم دفع مبلغ " . $amount . " ج.م - " . $title;
        $notificationType = "money";
    }

    if ($notificationTitle !== "") {
        $notifyStmt = $conn->prepare("
            INSERT INTO notifications
(user_id, title, body, type, is_read, created_at)
VALUES
(:user_id, :title, :body, :type, 0, NOW())
        ");

       $notifyStmt->bindValue(
    ":user_id",
    $user_id,
    PDO::PARAM_INT
);
        $notifyStmt->bindValue(":title", $notificationTitle);
        $notifyStmt->bindValue(":body", $notificationBody);
        $notifyStmt->bindValue(":type", $notificationType);
        $notifyStmt->execute();
    }

    /*
        3) تحديث رصيد العميل تلقائيًا

        sale:
        بيع للعميل => يزيد الرصيد، لأن العميل بقى عليه فلوس.

        receive:
        استلام أموال من العميل => يقلل الرصيد.
        GREATEST تمنع الرصيد ينزل تحت صفر.

        pay:
        دفع أموال للعميل => يزيد الرصيد لو بتستخدمه كمديونية على العميل.
        لكن لو الدفع للمورد party_type = supplier مش هيأثر على clients.
    */
    if ($partyType === "client" && $partyId !== null) {
        if ($type === "sale") {
            $updateBalance = $conn->prepare("
                UPDATE clients
                SET 
                    balance = balance + :amount,
                    last_activity = NOW()
                WHERE id = :id
            ");

            $updateBalance->bindValue(":amount", $amount);
            $updateBalance->bindValue(":id", $partyId, PDO::PARAM_INT);
            $updateBalance->execute();
        }

        if ($type === "receive") {
            $updateBalance = $conn->prepare("
                UPDATE clients
                SET 
                    balance = GREATEST(balance - :amount, 0),
                    last_activity = NOW()
                WHERE id = :id
            ");

            $updateBalance->bindValue(":amount", $amount);
            $updateBalance->bindValue(":id", $partyId, PDO::PARAM_INT);
            $updateBalance->execute();
        }

        if ($type === "pay") {
            $updateBalance = $conn->prepare("
                UPDATE clients
                SET 
                    balance = balance + :amount,
                    last_activity = NOW()
                WHERE id = :id
            ");

            $updateBalance->bindValue(":amount", $amount);
            $updateBalance->bindValue(":id", $partyId, PDO::PARAM_INT);
            $updateBalance->execute();
        }
    }
    /*
    تحديث رصيد الموردين
*/

if ($partyType === "supplier" && $partyId !== null) {

    // شراء من مورد => يزيد المديونية للمورد
    if ($type === "purchase") {

        $updateBalance = $conn->prepare("
            UPDATE suppliers
            SET balance = balance + :amount
            WHERE id = :id
        ");

        $updateBalance->bindValue(":amount", $amount);
        $updateBalance->bindValue(":id", $partyId, PDO::PARAM_INT);
        $updateBalance->execute();
    }

    // دفع للمورد => يقلل المديونية
    if ($type === "pay") {

        $updateBalance = $conn->prepare("
            UPDATE suppliers
            SET balance = GREATEST(balance - :amount, 0)
            WHERE id = :id
        ");

        $updateBalance->bindValue(":amount", $amount);
        $updateBalance->bindValue(":id", $partyId, PDO::PARAM_INT);
        $updateBalance->execute();
    }
}

    $conn->commit();

    echo json_encode([
        "success" => true,
        "message" => "Transaction added successfully",
        "transaction_id" => $transactionId
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }

    echo json_encode([
        "success" => false,
        "message" => "Server error",
        "error" => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>