<?php
require_once "../config/db.php";
require_once "../helpers/response.php";

$input = json_decode(file_get_contents("php://input"), true);

$client_id = intval($input["client_id"] ?? 0);

if ($client_id <= 0) {
    response(false, "client_id مطلوب", null, 400);
}

try {
    $stmt = $conn->prepare("
        UPDATE clients
        SET last_activity = NOW()
        WHERE id = :id
    ");

    $stmt->execute([":id" => $client_id]);

    response(true, "تم تحديث نشاط العميل");

} catch (Exception $e) {
    response(false, "فشل تحديث نشاط العميل", null, 500);
}