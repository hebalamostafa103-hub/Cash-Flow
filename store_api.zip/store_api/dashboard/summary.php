<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once "../config/db.php";
$input = json_decode(
    file_get_contents("php://input"),
    true
);

$user_id = intval(
    $input["user_id"] ?? 0
);

try {
    $clientsCountStmt = $conn->prepare("
    SELECT COUNT(*) AS total_clients
    FROM clients
    WHERE user_id = :user_id
");

$clientsCountStmt->execute([
    ":user_id" => $user_id
]);
    
    $clientsCount = $clientsCountStmt->fetch(PDO::FETCH_ASSOC);

    $clientsBalanceStmt = $conn->prepare("
    SELECT COALESCE(SUM(balance), 0) AS total_client_balance
    FROM clients
    WHERE user_id = :user_id
");

$clientsBalanceStmt->execute([
    ":user_id" => $user_id
]);
    
    $clientsBalance = $clientsBalanceStmt->fetch(PDO::FETCH_ASSOC);

    $totalsStmt = $conn->prepare("
        SELECT 
            COALESCE(SUM(CASE WHEN type = 'sale' THEN amount ELSE 0 END), 0) AS total_sales,
            COALESCE(SUM(CASE WHEN type = 'purchase' THEN amount ELSE 0 END), 0) AS total_purchases,
            COALESCE(SUM(CASE WHEN type = 'receive' THEN amount ELSE 0 END), 0) AS total_received,
            COALESCE(SUM(CASE WHEN type = 'pay' THEN amount ELSE 0 END), 0) AS total_paid
        FROM transactions
WHERE user_id = :user_id
    ");
    $totalsStmt->execute([
    ":user_id" => $user_id
]);
    $totals = $totalsStmt->fetch(PDO::FETCH_ASSOC);

    $todayStmt = $conn->prepare("
        SELECT 
            COALESCE(SUM(CASE WHEN type = 'sale' THEN amount ELSE 0 END), 0) AS today_sales,
            COALESCE(SUM(CASE WHEN type = 'purchase' THEN amount ELSE 0 END), 0) AS today_purchases,
            COALESCE(SUM(CASE WHEN type = 'receive' THEN amount ELSE 0 END), 0) AS today_received,
            COALESCE(SUM(CASE WHEN type = 'pay' THEN amount ELSE 0 END), 0) AS today_paid
        FROM transactions
        WHERE user_id = :user_id
AND DATE(created_at) = CURDATE()
    ");
    $todayStmt->execute([
    ":user_id" => $user_id
]);
    $today = $todayStmt->fetch(PDO::FETCH_ASSOC);

    $latestStmt = $conn->prepare("
    SELECT
        id,
        type,
        party_type,
        party_id,
        title,
        amount,
        note,
        created_at
    FROM transactions
    WHERE user_id = :user_id
    ORDER BY id DESC
    LIMIT 5
");

$latestStmt->execute([
    ":user_id" => $user_id
]);
    
    $latestTransactions = $latestStmt->fetchAll(PDO::FETCH_ASSOC);

    $inactiveStmt = $conn->prepare("
    SELECT
        id,
        name,
        phone,
        balance,
        status,
        last_activity,
        DATEDIFF(NOW(), last_activity) AS inactive_days
    FROM clients
    WHERE user_id = :user_id
    AND last_activity IS NOT NULL
    ORDER BY last_activity ASC
    LIMIT 5
");

$inactiveStmt->execute([
    ":user_id" => $user_id
]);
    
    $inactiveClients = $inactiveStmt->fetchAll(PDO::FETCH_ASSOC);
    $topPaidStmt = $conn->prepare("
    SELECT name, balance
    FROM clients
    WHERE user_id = :user_id
    ORDER BY balance DESC
    LIMIT 1
");

$topPaidStmt->execute([
    ":user_id" => $user_id
]);


$topPaidClient =
    $topPaidStmt->fetch(PDO::FETCH_ASSOC);
    if (!$topPaidClient) {
    $topPaidClient = [
        "name" => "لا يوجد",
        "balance" => 0
    ];
}

$topDebtStmt = $conn->prepare("
    SELECT name, balance
    FROM clients
    WHERE user_id = :user_id
    ORDER BY balance ASC
    LIMIT 1
");

$topDebtStmt->execute([
    ":user_id" => $user_id
]);


$topDebtClient =
    $topDebtStmt->fetch(PDO::FETCH_ASSOC);
    if (!$topDebtClient) {
    $topDebtClient = [
        "name" => "لا يوجد",
        "balance" => 0
    ];
}

    echo json_encode([
        "success" => true,
        "message" => "Dashboard summary loaded",
        "data" => [
            "total_clients" => intval($clientsCount["total_clients"] ?? 0),
            "total_client_balance" => floatval($clientsBalance["total_client_balance"] ?? 0),

            "total_sales" => floatval($totals["total_sales"] ?? 0),
            "total_purchases" => floatval($totals["total_purchases"] ?? 0),
            "total_received" => floatval($totals["total_received"] ?? 0),
            "total_paid" => floatval($totals["total_paid"] ?? 0),

            "today_sales" => floatval($today["today_sales"] ?? 0),
            "today_purchases" => floatval($today["today_purchases"] ?? 0),
            "today_received" => floatval($today["today_received"] ?? 0),
            "today_paid" => floatval($today["today_paid"] ?? 0),

            "latest_transactions" => $latestTransactions,
            "inactive_clients" => $inactiveClients,

"top_paid_client" => $topPaidClient,
"top_debt_client" => $topDebtClient
        ]
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Server error",
        "error" => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>