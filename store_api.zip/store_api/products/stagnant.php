<?php
require_once "../config/db.php";
require_once "../helpers/response.php";

$days = intval($_GET["days"] ?? 30);

try {
    $stmt = $conn->prepare("
        SELECT *,
        DATEDIFF(NOW(), last_move) AS stagnant_days
        FROM products
        WHERE last_move < DATE_SUB(NOW(), INTERVAL :days DAY)
        ORDER BY last_move ASC
    ");

    $stmt->bindValue(":days", $days, PDO::PARAM_INT);
    $stmt->execute();

    response(true, "Stagnant products loaded", $stmt->fetchAll());

} catch (Exception $e) {
    response(false, "Failed to load stagnant products", null, 500);
}