<?php
header("Content-Type: application/json; charset=UTF-8");
require_once "../config.php";

$input = json_decode(file_get_contents("php://input"), true);

$id = isset($input["id"]) ? intval($input["id"]) : 0;

if ($id <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid notification id"
    ]);
    exit;
}

$stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Notification marked as read"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to update notification"
    ]);
}

$stmt->close();
$conn->close();
?>