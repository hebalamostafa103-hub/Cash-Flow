<?php

require_once "../config/db.php";
require_once "../helpers/response.php";

$data = json_decode(file_get_contents("php://input"), true);

$user_id = intval($data["user_id"] ?? 0);
$name = trim($data["name"] ?? "");
$phone = trim($data["phone"] ?? "");

if ($user_id <= 0 || $name == "") {
    response(false, "Missing required fields", null, 400);
    exit;
}

try {

    $stmt = $conn->prepare("
        INSERT INTO suppliers
        (user_id, name, phone)
        VALUES (?, ?, ?)
    ");

    $stmt->execute([
        $user_id,
        $name,
        $phone
    ]);

    response(true, "Supplier added");

} catch (Exception $e) {

    response(
        false,
        $e->getMessage(),
        null,
        500
    );
}