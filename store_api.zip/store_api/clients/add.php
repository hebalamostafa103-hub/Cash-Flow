<?php
require_once "../config/db.php";
require_once "../helpers/response.php";

$input = json_decode(file_get_contents("php://input"), true);

$user_id = intval($input["user_id"] ?? 0);

$name = trim($input["name"] ?? "");
$phone = trim($input["phone"] ?? "");

if ($name === "") {
    response(false, "اسم العميل مطلوب", null, 400);
}

try {
    $stmt = $conn->prepare("
    INSERT INTO clients
    (
        user_id,
        name,
        phone,
        balance,
        status,
        last_activity
    )
    VALUES
    (
        :user_id,
        :name,
        :phone,
        0,
        'جديد',
        NOW()
    )
");

$stmt->execute([
    ":user_id" => $user_id,
    ":name" => $name,
    ":phone" => $phone
]);

    response(true, "تم إضافة العميل", [
        "id" => $conn->lastInsertId()
    ], 201);

} catch (Exception $e) {
    response(false, "فشل إضافة العميل", null, 500);
}