<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once "../config/db.php";

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!$data) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid JSON body"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$email = isset($data["email"]) ? trim($data["email"]) : "";
$password = isset($data["password"]) ? trim($data["password"]) : "";

if ($email === "" || $password === "") {
    echo json_encode([
        "success" => false,
        "message" => "البريد الإلكتروني وكلمة المرور مطلوبين"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $stmt = $conn->prepare("
        SELECT 
            id,
            name,
            phone,
            email,
            password,
            role,
            created_at
        FROM users
        WHERE email = :email
        LIMIT 1
    ");

    $stmt->bindValue(":email", $email);
    $stmt->execute();

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode([
            "success" => false,
            "message" => "البريد الإلكتروني أو كلمة المرور غير صحيحة"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($password !== $user["password"]) {
        echo json_encode([
            "success" => false,
            "message" => "البريد الإلكتروني أو كلمة المرور غير صحيحة"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    unset($user["password"]);

    echo json_encode([
        "success" => true,
        "message" => "Login successful",
        "data" => $user
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Server error",
        "error" => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>