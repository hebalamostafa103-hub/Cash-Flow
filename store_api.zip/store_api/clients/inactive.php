<?php

require_once "../config/db.php";
require_once "../helpers/response.php";

$data = json_decode(
    file_get_contents("php://input"),
    true
);

$user_id = intval(
    $data["user_id"] ?? 0
);

$days = intval(
    $data["days"] ?? 30
);

try {

    $stmt = $conn->prepare("
        SELECT *,
        DATEDIFF(NOW(), last_activity) AS inactive_days
        FROM clients
        WHERE user_id = ?
        AND last_activity < DATE_SUB(NOW(), INTERVAL ? DAY)
        ORDER BY last_activity ASC
    ");

    $stmt->execute([
        $user_id,
        $days
    ]);

    response(
        true,
        "Inactive clients loaded",
        $stmt->fetchAll()
    );

} catch (Exception $e) {

    response(
        false,
        "Failed to load inactive clients",
        null,
        500
    );
}