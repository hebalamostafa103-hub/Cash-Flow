<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once "../config/db.php";

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!$data) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid JSON body"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$userId = isset($data["user_id"]) ? intval($data["user_id"]) : 0;
$code = isset($data["code"]) ? trim($data["code"]) : "";

if ($userId <= 0 || $code === "") {
    echo json_encode([
        "success" => false,
        "message" => "بيانات التحقق غير مكتملة"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $stmt = $conn->prepare("
        SELECT id, code, expires_at, is_used
        FROM otp_codes
        WHERE user_id = :user_id
        ORDER BY id DESC
        LIMIT 1
    ");

    $stmt->bindValue(":user_id", $userId, PDO::PARAM_INT);
    $stmt->execute();

    $otp = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$otp) {
        echo json_encode([
            "success" => false,
            "message" => "لا يوجد كود تحقق لهذا الحساب"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (intval($otp["is_used"]) === 1) {
        echo json_encode([
            "success" => false,
            "message" => "تم استخدام هذا الكود من قبل"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (strtotime($otp["expires_at"]) < time()) {
        echo json_encode([
            "success" => false,
            "message" => "انتهت صلاحية الكود"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($otp["code"] !== $code) {
        echo json_encode([
            "success" => false,
            "message" => "كود التحقق غير صحيح"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $otpId = intval($otp["id"]);

    $markOtp = $conn->prepare("
        UPDATE otp_codes
        SET is_used = 1
        WHERE id = :id
    ");
    $markOtp->bindValue(":id", $otpId, PDO::PARAM_INT);
    $markOtp->execute();

    $verifyUser = $conn->prepare("
        UPDATE users
        SET is_verified = 1
        WHERE id = :user_id
    ");
    $verifyUser->bindValue(":user_id", $userId, PDO::PARAM_INT);
    $verifyUser->execute();

    echo json_encode([
        "success" => true,
        "message" => "تم تفعيل الحساب بنجاح"
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Server error",
        "error" => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>