<?php

require_once "../config/db.php";
require_once "../helpers/response.php";

$data = json_decode(
    file_get_contents("php://input"),
    true
);

$user_id = intval(
    $data["user_id"] ?? 0
);

try {

    $stmt = $conn->prepare(
        "SELECT *
         FROM suppliers
         WHERE user_id = ?
         ORDER BY id DESC"
    );

    $stmt->execute([$user_id]);

    response(
        true,
        "Suppliers loaded",
        $stmt->fetchAll()
    );

} catch (Exception $e) {

    response(
        false,
        "Failed to load suppliers",
        null,
        500
    );

}