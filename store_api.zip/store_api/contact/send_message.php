<?php

header("Content-Type: application/json");

require_once "../vendor/autoload.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$data = json_decode(
file_get_contents("php://input"),
true
);

$name =
$data["name"] ?? "";

$email =
$data["email"] ?? "";

$message =
$data["message"] ?? "";

$mail = new PHPMailer(true);

try{

$mail->isSMTP();

$mail->Host = "smtp.gmail.com";

$mail->SMTPAuth = true;

$mail->Username = "mostafahmed662@gmail.com
";

$mail->Password = "bahv lbns kyns imcc";

$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;

$mail->Port = 587;

$mail->setFrom(
"mostafahmed662@gmail.com
",
"Wallet App"
);

$mail->addAddress(
"mostafahmed662@gmail.com
"
);

$mail->Subject =
"New Contact Message";

$mail->Body =

"Name: $name\n\n".

"Email: $email\n\n".

"Message:\n$message";

$mail->send();

echo json_encode([

"success"=>true

]);

}
catch(Exception $e){

echo json_encode([

"success"=>false,

"error"=>$mail->ErrorInfo

]);

}