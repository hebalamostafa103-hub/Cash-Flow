<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once "../config/db.php";

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!$data) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid JSON body"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$userId = isset($data["user_id"]) ? intval($data["user_id"]) : 0;

if ($userId <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "رقم المستخدم غير صحيح"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $userStmt = $conn->prepare("
        SELECT id, phone, is_verified
        FROM users
        WHERE id = :id
        LIMIT 1
    ");

    $userStmt->bindValue(":id", $userId, PDO::PARAM_INT);
    $userStmt->execute();

    $user = $userStmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode([
            "success" => false,
            "message" => "المستخدم غير موجود"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (intval($user["is_verified"]) === 1) {
        echo json_encode([
            "success" => false,
            "message" => "الحساب مفعل بالفعل"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $phone = $user["phone"];
    $otp = strval(random_int(100000, 999999));
    $expiresAt = date("Y-m-d H:i:s", time() + (5 * 60));

    $otpStmt = $conn->prepare("
        INSERT INTO otp_codes
        (user_id, phone, code, expires_at, is_used, created_at)
        VALUES
        (:user_id, :phone, :code, :expires_at, 0, NOW())
    ");

    $otpStmt->bindValue(":user_id", $userId, PDO::PARAM_INT);
    $otpStmt->bindValue(":phone", $phone);
    $otpStmt->bindValue(":code", $otp);
    $otpStmt->bindValue(":expires_at", $expiresAt);
    $otpStmt->execute();

    echo json_encode([
        "success" => true,
        "message" => "تم إنشاء كود تحقق جديد",
        "demo_otp" => $otp
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Server error",
        "error" => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>