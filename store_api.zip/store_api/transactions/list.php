<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once "../config/db.php";
$input = json_decode(
    file_get_contents("php://input"),
    true
);

$user_id = intval(
    $input["user_id"] ?? 0
);

try {
    $stmt = $conn->prepare("
    SELECT
        id,
        type,
        party_type,
        party_id,
        title,
        amount,
        note,
        created_at
    FROM transactions
    WHERE user_id = :user_id
    ORDER BY id DESC
");

    $stmt->execute([
    ":user_id" => $user_id
]);
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "success" => true,
        "message" => "Transactions loaded",
        "data" => $transactions
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Server error",
        "error" => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>