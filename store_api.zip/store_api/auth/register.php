<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once "../config/db.php";
require "../vendor/autoload.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!$data) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid JSON body"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$name = isset($data["name"]) ? trim($data["name"]) : "";
$phone = isset($data["phone"]) ? trim($data["phone"]) : "";
$email = isset($data["email"]) ? trim($data["email"]) : "";
$password = isset($data["password"]) ? trim($data["password"]) : "";
$role = isset($data["role"]) ? trim($data["role"]) : "assistant";

if ($name === "" || $phone === "" || $email === "" || $password === "") {
    echo json_encode([
        "success" => false,
        "message" => "كل البيانات مطلوبة"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        "success" => false,
        "message" => "البريد الإلكتروني غير صحيح"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if (strlen($password) < 6) {
    echo json_encode([
        "success" => false,
        "message" => "كلمة المرور يجب ألا تقل عن 6 أرقام أو حروف"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$allowedRoles = ["owner", "assistant", "collector", "warehouse"];

if (!in_array($role, $allowedRoles)) {
    $role = "assistant";
}

try {
    /*
        نتأكد إن الإيميل أو الموبايل مش موجودين قبل كده
    */
    $check = $conn->prepare("
        SELECT id, email, phone
        FROM users
        WHERE email = :email OR phone = :phone
        LIMIT 1
    ");

    $check->bindValue(":email", $email);
    $check->bindValue(":phone", $phone);
    $check->execute();

    $exists = $check->fetch(PDO::FETCH_ASSOC);

    if ($exists) {
        if ($exists["email"] === $email) {
            echo json_encode([
                "success" => false,
                "message" => "البريد الإلكتروني مستخدم بالفعل"
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($exists["phone"] === $phone) {
            echo json_encode([
                "success" => false,
                "message" => "رقم الهاتف مستخدم بالفعل"
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    /*
        ملاحظة:
        حاليًا نخزن الباسورد عادي عشان login.php عندك بيقارن عادي.
        بعد ما التسجيل يشتغل، نقدر نعمل تشفير password_hash/password_verify.
    */
    $stmt = $conn->prepare("
    INSERT INTO users
    (name, phone, email, password, role, is_verified, created_at)
    VALUES
    (:name, :phone, :email, :password, :role, 0, NOW())
");

$stmt->bindValue(":name", $name);
$stmt->bindValue(":phone", $phone);
$stmt->bindValue(":email", $email);
$stmt->bindValue(":password", $password);
$stmt->bindValue(":role", $role);
$stmt->execute();

$userId = $conn->lastInsertId();

/*
    Demo OTP:
    هنا بنولد كود تحقق ونخزنه في جدول otp_codes.
    في النسخة الحقيقية الكود ده يتبعت واتساب أو SMS.
*/
$otp = strval(random_int(100000, 999999));
$expiresAt = date("Y-m-d H:i:s", time() + (5 * 60));

$otpStmt = $conn->prepare("
    INSERT INTO otp_codes
    (user_id, phone, code, expires_at, is_used, created_at)
    VALUES
    (:user_id, :phone, :code, :expires_at, 0, NOW())
");

$otpStmt->bindValue(":user_id", $userId);
$otpStmt->bindValue(":phone", $phone);
$otpStmt->bindValue(":code", $otp);
$otpStmt->bindValue(":expires_at", $expiresAt);
$otpStmt->execute();
$mail = new PHPMailer(true);

$mail->isSMTP();

$mail->Host = "smtp.gmail.com";

$mail->SMTPAuth = true;

$mail->Username =
"mostafahmed662@gmail.com
";

$mail->Password =
"bahv lbns kyns imcc
";

$mail->SMTPSecure =
PHPMailer::ENCRYPTION_STARTTLS;

$mail->Port = 587;

$mail->setFrom(
"mostafahmed662@gmail.com
",
"Store App"
);

$mail->addAddress($email);

$mail->isHTML(true);

$mail->Subject =
"Verification Code";

$mail->Body =
"<h2>Your OTP:</h2>
<h1>$otp</h1>";

try{

$mail->send();

}

catch(Exception $mailError){

echo json_encode([

"success"=>false,

"message"=>$mail->ErrorInfo

]);

exit;

}

echo json_encode([
    "success" => true,
    "message" => "تم إرسال كود التحقق على البريد",
    "data" => [
        "id" => $userId,
        "name" => $name,
        "phone" => $phone,
        "email" => $email,
        "role" => $role,
        "is_verified" => 0
    ],
    
], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Server error",
        "error" => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>